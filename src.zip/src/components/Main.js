import React, { useState } from 'react';

const Main = () => {
  const [pollOptions, setPollOptions] = useState([
    { id: 1, text: 'Option A', votes: 0 },
    { id: 2, text: 'Option B', votes: 0 },
    { id: 3, text: 'Option C', votes: 0 },
  ]);

  const backgroundStyle = {
    backgroundImage: 'url("https://www.shutterstock.com/image-illustration/community-vote-voting-diversity-concept-diverse-1615848271")',
    display: 'flex',
    backgroundSize: 'contain',
    backgroundPosition: 'left',
    textAlign: 'left',
    height: '750px',
  };

  const containerStyle = {
    width: '500px',
    maxHeight: '500px',
    margin: '50px auto',
    padding: '20px',
    marginTop: '160px',
    border: '1px solid #ccc',
    borderRadius: '8px',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
    textAlign: 'center',
    backgroundPosition: 'left',
    background: 'white',
    opacity: '0.9'
  };

  const headingStyle = {
    marginBottom: '20px',
    color: '#333',
    fontSize: '24px',
  };

  const questionStyle = {
    color: '#555',
    marginBottom: '20px',
  };

  const optionsStyle = {
    listStyle: 'none',
    padding: '0',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    backgroundPosition: 'left',
  };

  const listItemStyle = {
    marginBottom: '10px',
    padding: '15px',
    border: '1px solid #ddd',
    borderRadius: '8px',
    background: '#fff',
    width: '100%',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'left',
    transition: 'background 0.3s ease',
    cursor: 'pointer',
  };

  const labelStyle = {
    cursor: 'pointer',
    color: '#555',
    fontSize: '16px',
  };

  const votesStyle = {
    marginLeft: '10px',
    fontWeight: 'bold',
    color: '#555',
  };

  const totalVotesStyle = {
    marginTop: '20px',
    fontWeight: 'bold',
    color: '#333',
  };

  const handleVote = (optionId) => {
    setPollOptions((prevOptions) =>
      prevOptions.map((option) =>
        option.id === optionId ? { ...option, votes: option.votes + 1 } : option
      )
    );
  };

  const handleLogin = () => {
    console.log('Logged in');
  };

  return (
    <div style={backgroundStyle}>
      <div style={containerStyle}>
        <h1 style={headingStyle}>Polling System</h1>
        <p style={questionStyle}>GO ON!!</p>
        <ul style={optionsStyle}>
          {pollOptions.map((option) => (
            <li key={option.id} style={listItemStyle}>
              <label style={labelStyle}>
                <input
                  type="radio"
                  name="pollOption"
                  value={option.id}
                  onChange={() => handleVote(option.id)}
                />
                {option.text}
              </label>
              <span style={votesStyle}>
                Votes: {option.votes} ({((option.votes / pollOptions.reduce((total, opt) => total + opt.votes, 0)) * 100).toFixed(2)}%)
              </span>
            </li>
          ))}
        </ul>
        <p style={totalVotesStyle}>
          Total Votes: {pollOptions.reduce((total, option) => total + option.votes, 0)}
        </p>
        {/* "Make your choice" element */}
        <p style={{ marginTop: '50px', fontWeight: 'bold', color: 'black' }}>MAKE YOUR CHOICE!!!</p>

      </div>
    </div>
  );
};

export default Main;

